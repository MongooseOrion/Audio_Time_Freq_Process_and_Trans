# Speech Emotion Recognition

Deep Learning - Assignment for MSc in Artificial Intelligence 2020-2021 (University of Piraeus-NCSR DEMOKRITOS).

Title: Speech Emotion Recognition with CNN using MFCCs<br>
Authors: Stergios Giannios, Thanasis Tsitos

[Jupyter Notebook Viewer](https://nbviewer.jupyter.org/github/Stergios-Giannios/speech-emotion-recognition/blob/main/audio_emotion.ipynb)<br>
[Presentation](https://docs.google.com/presentation/d/122DzUyjJmdP8cFSBzjRKzea9f_ZP3y583UKhoCYU-Fc/edit?usp=sharing)
